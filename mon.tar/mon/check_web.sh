#!/bin/bash
###############################################################################################
## File name : check_web.sh ( Apache / Tomcat )
## Description : Apache Tomcat check Script ( call web_mon_cron.sh )
## Information : Executed manually ( by user )
##=======================================================================================
##  version   date             author      reason
##---------------------------------------------------------------------------------------
##  1.0       2024.08.01       MW.STD      First Revision.
###############################################################################################

# ====================================================================================================
# Script ENV
# ====================================================================================================
SCRIPT_VERSION=1.0
ABSOLUTE_PATH="$(cd $(dirname "$0") && pwd -P)"
. ~/.bash_profile 1>/dev/null 2>&1
. "${ABSOLUTE_PATH}/web_mon_cron.env"

# ====================================================================================================
# Functions
# ====================================================================================================
###########################################################################
##  Function Name : print_msg
##  Description : Common Function for printing messages.
##  information : 
###########################################################################
print_msg() {
     printf "[%s _ %s] %-20s : %-10s - %-10s %-10s %-10s %-10s %-10s\n" $1 $2 $3 $4 $5 $6 $7 $8 $9 | sed -e 's/ *$/ /g' | tee -a ${MON_LOG}
}

###########################################################################
##  Function Name : banner 
##  Description : Print "OK" or "NOT OK" according to check result.
##  information : 
###########################################################################
banner()
{
    if [ ${HEALTH_RESULT} -eq 0 ];then
        echo " @@@@@@@ @    @"
        echo " @     @ @   @"
        echo " @     @ @  @"
        echo " @     @ @@@"
        echo " @     @ @  @"
        echo " @     @ @   @"
        echo " @@@@@@@ @    @"
        exit 0
    else
        echo " @     @ @@@@@@@ @@@@@@@         @@@@@@@ @    @"
        echo " @@    @ @     @    @            @     @ @   @"
        echo " @ @   @ @     @    @            @     @ @  @"
        echo " @  @  @ @     @    @            @     @ @@@"
        echo " @   @ @ @     @    @            @     @ @  @"
        echo " @    @@ @     @    @            @     @ @   @"
        echo " @     @ @@@@@@@    @            @@@@@@@ @    @"
        exit 1
    fi
}

###########################################################################
##  Function Name : main
##  Description : Check permission and crontab setting of web_mon_cron.sh
##  information : 
###########################################################################
main()
{
    clear

    if [ -x "${ABSOLUTE_PATH}/${CRONSHL}" ]; then
        ${ABSOLUTE_PATH}/${CRONSHL}
        HEALTH_RESULT=$?

        print_msg "${DATE}" "${USER}" "${CRONSHL}" "OK" "x_Permission"

        #if crontab -l | awk '!/^#/' | grep -q "${CRONSHL}"; then
        #    print_msg "${DATE}" "${USER}" "${CRONSHL}" "OK" "crontab"
        #else
        #    print_msg "${DATE}" "${USER}" "${CRONSHL}" "NOT.OK" "crontab"
        #    HEALTH_RESULT=$((HEALTH_RESULT + 1))
        #fi
    else
        print_msg "${DATE}" "${USER}" "${CRONSHL}" "NOT.OK" "x_Permission"
        HEALTH_RESULT=1
    fi

    banner
}

# ====================================================================================================
# Main
# ====================================================================================================
main
