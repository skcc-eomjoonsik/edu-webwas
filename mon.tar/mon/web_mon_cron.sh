#!/bin/bash
###############################################################################################
## File name : web_mon_cron.sh ( Apache / Tomcat )
## Description : Apache Tomcat check Script
## Information : crontab for automatic execution. Every 3 min. ( 1-59/3 )
##=======================================================================================
##  version   date             author      reason
##---------------------------------------------------------------------------------------
##  1.0       2024.08.01       MW.STD      First Revision.
###############################################################################################
# ===== crontab example =====
# 1-59/3 * * * * /home/webwas/shl/mon/web_mon_cron.sh                  1>/dev/null 2>&1
# ====================================================================================================

# ====================================================================================================
# Script ENV
# ====================================================================================================
SCRIPT_VERSION=1.0
ABSOLUTE_PATH="$(cd $(dirname "$0") && pwd -P)"
. ~/.bash_profile 1>/dev/null 2>&1
. ${ABSOLUTE_PATH}/web_mon_cron.env

            MYPID=$$

          PS_INFO=${MON_LOG_DIR}/ps_info.${RANDOM}
     NETSTAT_INFO=${MON_LOG_DIR}/netstat_info.${RANDOM}
    HEALTH_RESULT=${MON_LOG_DIR}/result.${RANDOM}
    SERVER_STATUS=${MON_LOG_DIR}/apache.server-status.${RANDOM}
NETSTAT_INFO_FILE=${MON_LOG_DIR}/netinfo/net_info.${DATE3}

       NOTOK_LIST=${MON_LOG_DIR}/notok.${RANDOM}
      NOTOK_LIST1=${MON_LOG_DIR}/notok1.${RANDOM}
      NOTOK_LIST2=${MON_LOG_DIR}/notok2.${RANDOM}
      NOTOK_LIST3=${MON_LOG_DIR}/notok3.${RANDOM}
             TMP1=${MON_LOG_DIR}/tmp1.${RANDOM}
             TMP2=${MON_LOG_DIR}/tmp2.${RANDOM}

# ====================================================================================================
# Functions
# ====================================================================================================
###########################################################################
##  Function Name : print_msg
##  Description : Common Function for printing messages if result is ok
##  information : 
###########################################################################
print_msg() {
    printf "[%s - %s] %-20s : %-10s - %-10s %-10s %-10s %-10s %-10s\n" $1 $2 $3 $4 $5 $6 $7 $8 $9 | sed -e 's/ *$/ /g' | tee -a ${MON_LOG}
}

###########################################################################
##  Function Name : print_msg_nok
##  Description : Common Function for printing messages if result is not ok
##  information : 
###########################################################################
print_msg_nok() {
    printf "[%s - %s] %-20s : %-10s - %-10s %-10s %-10s %-10s %-10s\n" "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" | sed -e 's/ *$/ /g' | tee -a ${MON_LOG} ${SMS_LOG}
    if [ "${IS_CLOUD}" = "Y" ]; then
        printf "${DATE4}||%s : %s - %s %s %s %s %s\n" "$3" "$4" "$5" "$6" "$7" "$8" "$9" | sed -e 's/ *$/ /g' >> ${CLOUD_LOG}
    fi
    RESULT_TEMP=$(cat ${HEALTH_RESULT})
    RESULT_TEMP=$((RESULT_TEMP + 1))
    echo ${RESULT_TEMP} > ${HEALTH_RESULT}
    [ ! -f ${LOG_NET_INFO} ] && cp -Rp ${NETSTAT_INFO} ${LOG_NET_INFO}
}

###########################################################################
##  Function Name : common
##  Description : Do general work before check
##  information : mkdir logdir, check files, make psinfo/netinfo files, print script version
###########################################################################
common()
{
    mkdir -p ${MON_LOG_DIR}/netinfo
    touch ${SMS_LOG} ${TMP1} ${TMP2} ${PS_INFO} ${NETSTAT_INFO}
    chmod 777 ${SMS_LOG}
    echo 0 > ${HEALTH_RESULT}
    ps -e -o user:20,pid,ppid,lstart,cmd | egrep -w "^root|^${USER}" > ${PS_INFO}
    netstat -nlt > ${NETSTAT_INFO}
    netstat -an > ${NETSTAT_INFO_FILE}
    printf "SCRIPT VERSION=%s\n" ${SCRIPT_VERSION}
}

###########################################################################
##  Function Name : remove_tmp_files
##  Description : gzip netinfo file, remove tmp files after check.
##  information :
###########################################################################
remove_tmp_files()
{
    gzip -f ${NETSTAT_INFO_FILE}
    OLD_NET=$(echo ${NETSTAT_INFO_FILE} | awk -F "/" '{print $NF}' | awk -F "." '{print $1}')
    find ${MON_LOG_DIR} -name "${OLD_NET}.`date -d 'yesterday' '+%Y%m%d'`*" -type f -exec rm -rf {} \;
    rm -f ${TMP1} ${TMP2} ${PS_INFO} ${NETSTAT_INFO} ${HEALTH_RESULT} ${SERVER_STATUS}
    find /tmp -user ${USER} -type f -name "linecnt.${USER}.*" -mtime +1 -exec rm -rf {} \; 2>/dev/null
}

###########################################################################
##  Function Name : chkshl_ppid_chk 
##  Description : Check which script executed this script ( check_web.sh or web_mon_cron.sh own )
##  information :
###########################################################################
chkshl_ppid_chk(){
    ppid=$(awk -v mypid=${MYPID} '$2 == mypid {print $3}' ${PS_INFO})
    ppidchk=$(grep -c "${ppid}" ${PS_INFO} | grep -c "${CHKSHL}")
}

###########################################################################
##  Function Name : mon_cron_cnt
##  Description : If web_mon_cron.sh process count is over MON_LIMIT(web_mon_cron.env), then print terror msg.
##  information :
###########################################################################
mon_cron_cnt(){
    SHELL_NAME=$(basename $0)
    WEB_MON_CNT=$(grep -c "${SHELL_NAME}" ${PS_INFO} | grep -Evw "vi|vim|tail|cat|grep|more")
    if [ ${WEB_MON_CNT} -gt ${MON_LIMIT} ]; then
        print_msg_nok ${DATE} ${USER} "web_mon_cron.sh" "NOT.OK" "[${WEB_MON_CNT}/${MON_LIMIT}]"
        remove_tmp_files
        exit 1
    fi
}

###########################################################################
##  Function Name : FileSystem
##  Description : If usage is over FS_LIMIT(web_mon_cron.env), then print error msg.
##  information :
###########################################################################
FileSystem()
{
    for FS in ${FS_LIST}; do
        df -kP ${FS} | awk 'NR>1 {print $(NF-1), $NF}' | sed -e "s/%//g" | while read -r USED MOUNT; do
            if [ ${USED} -gt ${FS_LIMIT} ]; then
                print_msg_nok ${DATE} ${USER} ${FUNCNAME[0]} "NOT.OK" "[${MOUNT}" "${USED}%]"
            else
                print_msg ${DATE} ${USER} ${FUNCNAME[0]} "OK" "[${MOUNT}" "${USED}%]"
            fi
        done
    done
}

###########################################################################
##  Function Name : log_file_scan
##  Description : If the log file contains error msg, then print it.
##  information :
###########################################################################
log_file_scan()
{
    local SERVER_NAME=$1
    local FILENAME=$2
    local LINE_CNT=$3
    local LOG_TYPE=$4
    local iFlag=$(wc -l < "${LINE_CNT}")

    local ERRORS_PATTERN="java.lang.OutOfMemoryError|as unavailable|Could not find worker with name|Could not get member list for lb worker|server reached MaxRequestWorkers setting|Pass phrase incorrect for key|\[Information\] SiteMinder Agent"
    local HTTP_ERRORS_PATTERN="500_code|503_code|\[500\]|\[503\]"
    local SYSDATE=$(date +'%Y%m%d')

    if [ "${iFlag}" -eq 0 ]; then
        echo "${SYSDATE}"                                                          > "${LINE_CNT}"
        wc -l < "${FILENAME}"                                                     >> "${LINE_CNT}"

        grep -E "${ERRORS_PATTERN}" "${FILENAME}"                                  > "${NOTOK_LIST1}"
        if ! grep -q "catalina.out" <<< "${FILENAME}"; then
            grep -E "${HTTP_ERRORS_PATTERN}" "${FILENAME}"                         > "${NOTOK_LIST2}"
        else
                                                                                   > "${NOTOK_LIST2}"
        fi
        grep "notifyStuckThreadDetected" "${FILENAME}"                             > "${NOTOK_LIST3}"
    else
        local PREV_SYSDATE=$(head -1 "${LINE_CNT}")
        if [ "${SYSDATE}" != "${PREV_SYSDATE}" ]; then
            echo "${SYSDATE}"                                                      > "${LINE_CNT}"
            wc -l < "${FILENAME}"                                                 >> "${LINE_CNT}"

            grep -E "${ERRORS_PATTERN}" "${FILENAME}"                              > "${NOTOK_LIST1}"
            if ! grep -q "catalina.out" <<< "${FILENAME}"; then
                grep -E "${HTTP_ERRORS_PATTERN}" "${FILENAME}"                     > "${NOTOK_LIST2}"
            else
                                                                                   > "${NOTOK_LIST2}"
            fi
            grep "notifyStuckThreadDetected" "${FILENAME}"                         > "${NOTOK_LIST3}"
        else
            local iPREV_LINE=$(tail -1 "${LINE_CNT}")
            local iLine=$(wc -l < "${FILENAME}")
            local iGAP=$((iLine - iPREV_LINE))

            echo "${SYSDATE}"                                                      > "${LINE_CNT}"
            echo "${iLine}"                                                       >> "${LINE_CNT}"

            tail -n "${iGAP}" "${FILENAME}" | grep -E "${ERRORS_PATTERN}"          > "${NOTOK_LIST1}"
            if ! grep -q "catalina.out" <<< "${FILENAME}"; then
                tail -n "${iGAP}" "${FILENAME}" | grep -E "${HTTP_ERRORS_PATTERN}" > "${NOTOK_LIST2}"
            else
                                                                                   > "${NOTOK_LIST2}"
            fi
            tail -n "${iGAP}" "${FILENAME}" | grep "notifyStuckThreadDetected"     > "${NOTOK_LIST3}"
        fi
    fi

    local CMN_ERR_CNT=$(wc -l < "${NOTOK_LIST1}")
    local ACC_ERR_CNT=$(wc -l < "${NOTOK_LIST2}")
    local STUCK_CNT=$(wc -l < "${NOTOK_LIST3}")

    if [ "${CMN_ERR_CNT}" -gt 0 ] || [ "${ACC_ERR_CNT}" -gt 0 ] || [ "${STUCK_CNT}" -gt 0 ]; then
        if [ "${CMN_ERR_CNT}" -gt 0 ]; then
            awk -v DT="${DATE}" -v USR="${USER}" -v SVR="${SERVER_NAME}" -v LT="${LOG_TYPE}" '
            /java.lang.OutOfMemoryError/               { printf "[%s - %s] %s : NOT.OK - [%s OutOfMemoryError happened.]\n", DT, USR, LT, SVR }
            /as unavailable/                           { printf "[%s - %s] %s : NOT.OK - [%s servlet status unavailable.]\n", DT, USR, LT, SVR }
            /Could not find worker with name/          { printf "[%s - %s] %s : NOT.OK - [%s Could not find worker]\n", DT, USR, LT, SVR }
            /Could not get member list for lb worker/  { printf "[%s - %s] %s : NOT.OK - [%s Could not get member list for lb worker]\n", DT, USR, LT, SVR }
            /server reached MaxRequestWorkers setting/ { printf "[%s - %s] %s : NOT.OK - [%s Server Reached MaxRequestWorkers setting]\n", DT, USR, LT, SVR }
            /failed to create worker/                  { printf "[%s - %s] %s : NOT.OK - [%s failed to create worker]\n", DT, USR, LT, SVR }
            /Pass phrase incorrect for key/            { printf "[%s - %s] %s : NOT.OK - [%s Pass phrase incorrect for key]\n", DT, USR, LT, SVR }
            ' "${NOTOK_LIST1}" | grep "^\[" | sort | uniq >> "${NOTOK_LIST}"

            print_msg "${DATE}" "${USER}" "${LOG_TYPE}" "NOT.OK" "[${FILENAME}]"
            cat "${NOTOK_LIST}" | tee -a "${SMS_LOG}"

            local RESULT_TEMP=$(<"${HEALTH_RESULT}")
            RESULT_TEMP=$((RESULT_TEMP + 1))
            echo "${RESULT_TEMP}" > "${HEALTH_RESULT}"
        fi

        if [ "${ACC_ERR_CNT}" -ge "${WAS_ERR_LIMIT}" ]; then
            print_msg_nok "${DATE}" "${USER}" "${LOG_TYPE}" "NOT.OK" "[${ACC_ERR_CNT}-50X_Errors" "${FILENAME}]"
        else
            print_msg     "${DATE}" "${USER}" "${LOG_TYPE}" "OK"     "[${ACC_ERR_CNT}-50X_Errors" "${FILENAME}]"
        fi

        if [ "${STUCK_CNT}" -ge "${STUCK_LIMIT}" ]; then
            print_msg_nok "${DATE}" "${USER}" "${LOG_TYPE}" "NOT.OK" "[${STUCK_CNT}-StuckThreads" "${FILENAME}]"
        else
            print_msg     "${DATE}" "${USER}" "${LOG_TYPE}" "OK"     "[${STUCK_CNT}-StuckThreads" "${FILENAME}]"
        fi

    else
        print_msg "${DATE}" "${USER}" "${LOG_TYPE}" "OK" "[${FILENAME}]"
    fi

    rm -f "${NOTOK_LIST}" "${NOTOK_LIST1}" "${NOTOK_LIST2}" "${NOTOK_LIST3}"
}

###########################################################################
##  Function Name : web_info_chk 
##  Description : Print apache version, apache home dir
##  information : 
###########################################################################
web_info_chk()
{
    # Apache version check
    WEB_VERSION=$("${APACHE_HOME}/bin/httpd" -v | head -1 | awk '{print $3}')
    echo "WEB_VERSION=${WEB_VERSION}"
    echo "WEB_HOME=${APACHE_HOME}"
}

###########################################################################
##  Function Name : was_info_chk 
##  Description : Print tomcat version, tomcat home dir
##  information : 
###########################################################################
was_info_chk()
{
    # Tomcat version check
    WAS_VERSION=$("${TOMCAT_HOME}/bin/version.sh" | grep "Server version" | awk '{print $NF}')
    echo "WAS_VERSION=${WAS_VERSION}"
    echo "WAS_HOME=${TOMCAT_HOME}"
}

# ====================================================================================================
# Apache functions
# ====================================================================================================
###########################################################################
##  Function Name : Apache_Daemon
##  Description : Check Apache Daemon Process is running
##  information :
###########################################################################
Apache_Daemon()
{
    for SERVER_NAME in "${APACHE_INST_NAME[@]}"
    do
        PID_WEB=$(awk '$3=="1" && /httpd/ && $0 ~ "'/${SERVER_NAME}'" && !/vi|vim|tail|cat|grep|more/' "$PS_INFO" | awk '{print $2}')
        CHILD_PROC=$(awk '/httpd -[f|k]/ && $0 ~ "^'"$USER"'" && $0 ~ "'/${SERVER_NAME}'" && !/vi|vim|tail|cat|grep|more/' "$PS_INFO" | wc -l)

        if [ -z "$PID_WEB" ]; then
            print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${CHILD_PROC}" "${SERVER_NAME}]"
        else
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${CHILD_PROC}" "${SERVER_NAME}]"
        fi
    done
}

###########################################################################
##  Function Name : Apache_HTTP_PORT
##  Description : Check Apache HTTP Service Port Status
##  information : 
###########################################################################
Apache_HTTP_PORT()
{
    for index in "${!APACHE_INST_NAME[@]}"; do
        local port="${APACHE_HTTP_PORT[${index}]}"
        local server_name="${APACHE_INST_NAME[${index}]}"

        if [ "${port}" = "-" ]; then
            continue
        fi

        local port_type_chk=$(grep -c ":" <<< "${port}")
        local listen_yn_http

        if [ "${port_type_chk}" -eq 0 ]; then
            listen_yn_http=$(awk '$NF=="LISTEN" && $4 ~ ":'"${port}"'$"' ${NETSTAT_INFO} | wc -l)
        else
            listen_yn_http=$(awk '$NF=="LISTEN" && $4 ~ "^'"${port}"'$"' ${NETSTAT_INFO} | wc -l)
        fi

        if [ "${listen_yn_http}" -eq 1 ]; then
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${port}" "${server_name}]"
        else
            sleep 1
            if [ "${port_type_chk}" -eq 0 ]; then
                listen_yn_http=$(netstat -an | awk '$NF=="LISTEN" && $4 ~ ":'"${port}"'$"' | wc -l)
            else
                listen_yn_http=$(netstat -an | awk '$NF=="LISTEN" && $4 ~ "^'"${port}"'$"' | wc -l)
            fi

            if [ "${listen_yn_http}" -eq 1 ]; then
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${port}" "${server_name}]"
            else
                print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${port}" "${server_name}]"
            fi
        fi
    done
}

###########################################################################
##  Function Name : Apache_HTTPS_PORT
##  Description : Check Apache HTTPS Service Port Status
##  information : 
###########################################################################
Apache_HTTPS_PORT()
{
    for index in "${!APACHE_INST_NAME[@]}"; do
        local port="${APACHE_HTTPS_PORT[${index}]}"
        local server_name="${APACHE_INST_NAME[${index}]}"

        if [ "${port}" = "-" ]; then
            continue
        fi

        local port_type_chk=$(grep -c ":" <<< "${port}")
        local listen_yn_http

        if [ "${port_type_chk}" -eq 0 ]; then
            listen_yn_http=$(awk '$NF=="LISTEN" && $4 ~ ":'"${port}"'$"' ${NETSTAT_INFO} | wc -l)
        else
            listen_yn_http=$(awk '$NF=="LISTEN" && $4 ~ "^'"${port}"'$"' ${NETSTAT_INFO} | wc -l)
        fi

        if [ "${listen_yn_http}" -eq 1 ]; then
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${port}" "${server_name}]"
        else
            sleep 1
            if [ "${port_type_chk}" -eq 0 ]; then
                listen_yn_http=$(netstat -an | awk '$NF=="LISTEN" && $4 ~ ":'"${port}"'$"' | wc -l)
            else
                listen_yn_http=$(netstat -an | awk '$NF=="LISTEN" && $4 ~ "^'"${port}"'$"' | wc -l)
            fi

            if [ "${listen_yn_http}" -eq 1 ]; then
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${port}" "${server_name}]"
            else
                print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${port}" "${server_name}]"
            fi
        fi
    done
}

###########################################################################
##  Function Name : Apache_SSL_VALID
##  Description : Verify SSL certificate expiration date.
##  information :
###########################################################################
Apache_SSL_VALID()
{
    if [ "${#APACHE_SSL_VALID[@]}" -eq 0 ]; then
        for index in "${!APACHE_INST_NAME[@]}"; do
            APACHE_SSL_VALID[${index}]="${APACHE_HTTPS_PORT[${index}]}"
        done
    fi

    for index in "${!APACHE_INST_NAME[@]}"; do
        local port="${APACHE_HTTPS_PORT[${index}]}"
        local ssl_valid_port="${APACHE_SSL_VALID[${index}]}"
        local server_name="${APACHE_INST_NAME[${index}]}"

        if [ "${ssl_valid_port}" = "-" ]; then
            continue
        fi

        local port_type_chk=$(grep -c ":" <<< "${port}")
        local is_run

        if [ "${port_type_chk}" -eq 0 ]; then
            is_run=$(awk '$NF=="LISTEN" && $4 ~ ":'"${port}"'$"' ${NETSTAT_INFO} | wc -l)
        else
            is_run=$(awk '$NF=="LISTEN" && $4 ~ "^'"${port}"'$"' ${NETSTAT_INFO} | wc -l)
        fi

        if [ "${is_run}" -eq 1 ]; then
            local ssl_type_chk=$(grep -c ":" <<< "${ssl_valid_port}")
            local enddate prtdate subject dt_today dt_edate diff_date

            if [ "${ssl_type_chk}" -eq 0 ]; then
                enddate=$(echo | openssl s_client -tls1 -connect 127.0.0.1:"${ssl_valid_port}" 2>/dev/null | openssl x509 -noout -enddate | cut -d'=' -f2 | awk '{print $1,$2,$4}')
                prtdate=$(awk '{print $3"-"$1"-"$2}' <<< "${enddate}")
                subject=$(echo | openssl s_client -tls1 -connect 127.0.0.1:"${ssl_valid_port}" 2>/dev/null | openssl x509 -noout -subject | awk -F"=" '{print $NF}')
            else
                enddate=$(echo | openssl s_client -tls1 -connect "${ssl_valid_port}" 2>/dev/null | openssl x509 -noout -enddate | cut -d'=' -f2 | awk '{print $1,$2,$4}')
                prtdate=$(awk '{print $3"-"$1"-"$2}' <<< "${enddate}")
                subject=$(echo | openssl s_client -tls1 -connect "${ssl_valid_port}" 2>/dev/null | openssl x509 -noout -subject | awk -F"=" '{print $NF}')
            fi

            dt_today=$(date -d "${TODAY}" "+%s")
            dt_edate=$(date -d "${enddate}" "+%s")
            diff_date=$(echo "(${dt_edate} - ${dt_today}) / 86400" | bc)

            if [ "${diff_date}" -gt "${SSL_EXPIRE_DAY}" ]; then
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${subject}" "${prtdate}" "${server_name}]"
            else
                print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${subject}" "${prtdate}" "${server_name}]"
            fi
        fi
    done
}

###########################################################################
##  Function Name : Apache_SSO_Filter
##  Description : Check if Apache is using the SSO Filter
##  information :
###########################################################################
Apache_SSO_Filter()
{
    local sso_pid=$(awk '$1 ~ /LLAWP/ && $3=="1" && !/vi|vim|tail|grep|cat|more/ {print $2}' "${PS_INFO}")
    local sso_conf=$(awk '$1 ~ /LLAWP/ && $3=="1" && !/vi|vim|tail|grep|cat|more/ {print $(NF-1)}' "${PS_INFO}")

    if [ -z "${sso_pid}" ]; then
        print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[LLAWP]"
    else
        print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[LLAWP(${sso_pid})" "${sso_conf}]"
    fi
}

###########################################################################
##  Function Name : Apache_Thread_Pool
##  Description : Check Apache Thread Pool Usage
##  information : need lynx pachage
###########################################################################
Apache_Thread_Pool()
{
    for index in "${!APACHE_INST_NAME[@]}"; do
        local port="${APACHE_HTTP_PORT[$index]}"
        local server_name="${APACHE_INST_NAME[$index]}"

        if [ "$port" = "-" ]; then
            continue
        fi

        local port_type_chk=$(grep -c ":" <<< "${port}")
        local is_running

        if [ "${port_type_chk}" -eq 0 ]; then
            is_running=$(awk '$NF=="LISTEN" && $4 ~ ":'"${port}"'$"' ${NETSTAT_INFO} | wc -l)
            local server_status_url="http://127.0.0.1:${port}/server-status"
        else
            is_running=$(awk '$NF=="LISTEN" && $4 ~ "^'"${port}"'$"' ${NETSTAT_INFO} | wc -l)
            local server_status_url="http://${port}/server-status"
        fi

        if [ "$is_running" -eq 1 ]; then
            #local server_status_url="http://${port}/server-status"
            local server_status_file="$SERVER_STATUS"
            local processed_workers idle_workers thread_count usage

            lynx -dump "$server_status_url" > "$server_status_file" 2>/dev/null
            processed_workers=$(awk '/requests currently being processed/ {print $1}' "$server_status_file")
            idle_workers=$(awk '/idle workers/ {print $(NF-2)}' "$server_status_file")

            if [ -n "$processed_workers" ] && [ -n "$idle_workers" ]; then
                thread_count="$processed_workers/$((${idle_workers} + ${processed_workers}))"
                usage=$(awk -F"/" '{printf "%d\n", $1/$2*100}' <<< "$thread_count")

                if [ "$usage" -ge "$THREAD_LIMIT" ]; then
                    print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[$thread_count $server_name]"
                else
                    print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[$thread_count $server_name]"
                fi
            fi
        fi
    done
}

###########################################################################
##  Function Name : Apache_Engine_Log
##  Description : Check Log File Exist, and call log_file_scan()
##  information : This function only check whether file exist
###########################################################################
Apache_Engine_Log()
{
    for index in "${!APACHE_INST_NAME[@]}"; do
        local server_name="${APACHE_INST_NAME[$index]}"
        local http_eline="${APACHE_HTTP_ELOG[$index]}"
        local https_eline="${APACHE_HTTPS_ELOG[$index]}"
        local line_cnt

        if [ "$http_eline" != "-" ]; then
            line_cnt="/tmp/linecnt.${USER}.${server_name}.error"
            touch "$line_cnt"

            if [ -f "$http_eline" ]; then
                log_file_scan "$server_name" "$http_eline" "$line_cnt" "${FUNCNAME[0]}"
            else
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[$http_eline]"
            fi
        fi

        if [ "$https_eline" != "-" ]; then
            line_cnt="/tmp/linecnt.${USER}.${server_name}.error_ssl"
            touch "$line_cnt"

            if [ -f "$https_eline" ]; then
                log_file_scan "$server_name" "$https_eline" "$line_cnt" "${FUNCNAME[0]}"
            else
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[$https_eline]"
            fi
        fi
    done
}

###########################################################################
##  Function Name : Apache_Access_Log
##  Description : Check Log File Exist, and call log_file_scan()
##  information : This function only check whether file exist
###########################################################################
Apache_Access_Log()
{
    for index in "${!APACHE_INST_NAME[@]}"; do
        local server_name="${APACHE_INST_NAME[$index]}"
        local http_alog="${APACHE_HTTP_ALOG[$index]}"
        local https_alog="${APACHE_HTTPS_ALOG[$index]}"
        local line_cnt

        if [ "$http_alog" != "-" ]; then
            line_cnt="/tmp/linecnt.${USER}.${server_name}.access"
            touch "$line_cnt"

            if [ -f "$http_alog" ]; then
                log_file_scan "$server_name" "$http_alog" "$line_cnt" "${FUNCNAME[0]}"
            else
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[$http_alog]"
            fi
        fi

        if [ "$https_alog" != "-" ]; then
            line_cnt="/tmp/linecnt.${USER}.${server_name}.access_ssl"
            touch "$line_cnt"

            if [ -f "$https_alog" ]; then
                log_file_scan "$server_name" "$https_alog" "$line_cnt" "${FUNCNAME[0]}"
            else
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[$https_alog]"
            fi
        fi
    done
}

###########################################################################
##  Function Name : Apache_Mod_jk_Log
##  Description : Check Log File Exist, and call log_file_scan()
##  information : This function only check whether file exist
###########################################################################
Apache_Mod_jk_Log()
{
    for index in "${!APACHE_INST_NAME[@]}"; do
        local server_name="${APACHE_INST_NAME[$index]}"
        local mod_jk_log="${APACHE_MOD_JK_LOG[$index]}"
        local line_cnt

        if [ "$mod_jk_log" != "-" ]; then
            line_cnt="/tmp/linecnt.${USER}.${server_name}.mod_jk"
            touch "$line_cnt"

            if [ -f "$mod_jk_log" ]; then
                log_file_scan "$server_name" "$mod_jk_log" "$line_cnt" "${FUNCNAME[0]}"
            else
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[$mod_jk_log]"
            fi
        fi
    done
}

###########################################################################
##  Function Name : Apache_Extra_Log
##  Description : Check Log File Exist, and call log_file_scan()
##  information : This function only check whether file exist
###########################################################################
Apache_Extra_Log()
{
    for index in "${!APACHE_EXTRA_LOG[@]}"; do
        local extra_log="${APACHE_EXTRA_LOG[$index]}"
        local line_cnt="/tmp/linecnt.${USER}.apache${index}.extralog"

        touch "$line_cnt"

        if [ -f "$extra_log" ]; then
            log_file_scan "apache${index}" "$extra_log" "$line_cnt" "${FUNCNAME[0]}"
        else
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[$extra_log]"
        fi
    done
}

###########################################################################
##  Function Name : Apache_Boot_Time
##  Description : Check Time When Apache Process started.
##  information : 
###########################################################################
Apache_Boot_Time()
{
    for server_name in "${APACHE_INST_NAME[@]}"; do
        local apache_boot_time
        local apache_boot_time_prt

        apache_boot_time=$(grep "httpd" "$PS_INFO" | grep "/${server_name}" | egrep -vw "vi|vim|tail|cat|grep|more" | awk '$3=="1" {print $4,$5,$6,$7,$8}')
        apache_boot_time_prt=$(date --date "${apache_boot_time}" +'%Y-%m-%d(%a) %H:%M:%S')

        print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${apache_boot_time_prt}" "${server_name}]"
    done
}

# ====================================================================================================
# Tomcat functions
# ====================================================================================================
###########################################################################
##  Function Name : Tomcat_Container
##  Description : Check Tomcat Daemon Process is running
##  information :
###########################################################################
Tomcat_Container()
{
    for server_name in "${TOMCAT_INST_NAME[@]}"; do
        local pid_was

        pid_was=$(grep "java" "${PS_INFO}" | egrep "D${server_name} |SERVER_NAME=${server_name} " | egrep -vw "vi|vim|tail|cat|grep|more" | awk '{print $2}')

        if [ -z "$pid_was" ]; then
            print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${server_name}]"
        else
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${server_name}" "${pid_was}]"
        fi
    done
}

###########################################################################
##  Function Name : Tomcat_PORT
##  Description : Check Tomcat Service Port Status
##  information : 
###########################################################################
Tomcat_PORT()
{
    for index in "${!TOMCAT_INST_NAME[@]}"; do
        # Function to check port
        check_port() {
            local port=$1
            local port_label=$2

            local port_type_chk=$(echo "${port}" | grep ":" | wc -l)
            local listen_yn

            if [ "${port_type_chk}" -eq 0 ]; then
                listen_yn=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep ":${port}$" | wc -l)
            else
                listen_yn=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep "^${port}$" | wc -l)
            fi

            if [ "${listen_yn}" -eq 1 ]; then
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${port}" "${TOMCAT_INST_NAME[${index}]}" "${port_label}]"
            else
                sleep 1
                if [ "${port_type_chk}" -eq 0 ]; then
                    listen_yn=$(netstat -an | grep "LISTEN " | awk '{print $4}' | grep ":${port}$" | wc -l)
                else
                    listen_yn=$(netstat -an | grep "LISTEN " | awk '{print $4}' | grep "^${port}$" | wc -l)
                fi

                if [ "${listen_yn}" -eq 1 ]; then
                    print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${port}" "${TOMCAT_INST_NAME[${index}]}" "${port_label}]"
                else
                    print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${port}" "${TOMCAT_INST_NAME[${index}]}" "${port_label}]"
                fi
            fi
        }

        # SDOWN PORT Check
        if [ "${TOMCAT_SDOWN_PORT[${index}]}" != "-" ]; then
            check_port "${TOMCAT_SDOWN_PORT[${index}]}" "SDOWN"
        fi

        # HTTP PORT Check
        if [ "${TOMCAT_HTTP_PORT[${index}]}" != "-" ]; then
            check_port "${TOMCAT_HTTP_PORT[${index}]}" "HTTP"
        fi

        # HTTPS PORT Check
        if [ "${TOMCAT_HTTPS_PORT[${index}]}" != "-" ]; then
            check_port "${TOMCAT_HTTPS_PORT[${index}]}" "HTTPS"
        fi

        # AJP PORT Check
        if [ "${TOMCAT_AJP_PORT[${index}]}" != "-" ]; then
            check_port "${TOMCAT_AJP_PORT[${index}]}" "AJP"
        fi
    done
}

###########################################################################
##  Function Name : Tomcat_SSL_VALID
##  Description : Verify SSL certificate expiration date.
##  information :
###########################################################################
Tomcat_SSL_VALID()
{
    for index in "${!TOMCAT_INST_NAME[@]}"; do
        if [ "${TOMCAT_HTTPS_PORT[${index}]}" = "-" ]; then
            # skip check if value is "-"
            continue
        fi

        local port="${TOMCAT_HTTPS_PORT[${index}]}"
        local port_type_chk=$(echo "${port}" | grep ":" | wc -l)
        local is_run

        if [ "${port_type_chk}" -eq 0 ]; then
            is_run=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep ":${port}$" | wc -l)
        else
            is_run=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep "^${port}$" | wc -l)
        fi

        if [ "${is_run}" -eq 1 ]; then
            local enddate
            local prtdate
            local subject
            local dt_today
            local dt_edate
            local diff_date

            if [ "${port_type_chk}" -eq 0 ]; then
                enddate=$(echo | openssl s_client -tls1 -connect 127.0.0.1:${port} 2>/dev/null | openssl x509 -noout -enddate | cut -d'=' -f2 | awk '{print $1, $2, $4}')
                prtdate=$(echo "${enddate}" | awk '{print $3"-"$1"-"$2}')
                subject=$(echo | openssl s_client -tls1 -connect 127.0.0.1:${port} 2>/dev/null | openssl x509 -noout -subject | awk -F"=" '{print $NF}')
            else
                enddate=$(echo | openssl s_client -tls1 -connect ${port} 2>/dev/null | openssl x509 -noout -enddate | cut -d'=' -f2 | awk '{print $1, $2, $4}')
                prtdate=$(echo "${enddate}" | awk '{print $3"-"$1"-"$2}')
                subject=$(echo | openssl s_client -tls1 -connect ${port} 2>/dev/null | openssl x509 -noout -subject | awk -F"=" '{print $NF}')
            fi

            dt_today=$(date -d "${TODAY}" "+%s")
            dt_edate=$(date -d "${enddate}" "+%s")
            diff_date=$(echo "(${dt_edate} - ${dt_today}) / 3600" | bc)

            if [ "${diff_date}" -gt 0 ]; then
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${subject}" "${prtdate}" "${TOMCAT_INST_NAME[${index}]}]"
            else
                print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${subject}" "${prtdate}" "${TOMCAT_INST_NAME[${index}]}]"
            fi
        fi
    done
}

###########################################################################
##  Function Name : Tomcat_Thread_Pool
##  Description : Check Tomcat Thread Pool Usage
##  information : need probe deployment & lynx pachage
###########################################################################
Tomcat_Thread_Pool() {
    local PAGE=threadpools.htm
    local RESULT=${PROBE_TMP}.${USER}.${RANDOM}
    local RESULT_TMP=${PROBE_TMP}.${USER}.${RANDOM}

    for index in "${!TOMCAT_INST_NAME[@]}"; do
        local port="${TOMCAT_HTTP_PORT[${index}]}"
        local port_type_chk=$(echo "${port}" | grep ":" | wc -l)
        local is_run
        local url

        if [ "${port_type_chk}" -eq 0 ]; then
            is_run=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep ":${port}$" | wc -l)
            url="http://127.0.0.1:${port}/probe/${PAGE}"
        else
            is_run=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep "^${port}$" | wc -l)
            url="http://${port}/probe/${PAGE}"
        fi

        if [ "${is_run}" -eq 1 ]; then
            lynx ${OPT} "${url}" > "${RESULT_TMP}" 2>/dev/null

            case ${PROBE_VERSION} in
                "3")
                    grep "^[ ]*\"" "${RESULT_TMP}" | grep -v "\"Silk\"" | sed -e "s/\"//g" | awk '{printf "%s/%s %-13s\n", $3, $2, $1}' > "${RESULT}"
                    ;;
                "2")
                    grep "^[ ]*http|^[ ]*jk|^[ ]*https|^[ ]*\"" "${RESULT_TMP}" | grep -v "\"Silk\"" | sed -e "s/\"//g" | awk '{printf "%s/%s %-13s\n", $3, $2, $1}' > "${RESULT}"
                    ;;
            esac

            while read -r THREAD_CNT THREAD_NAME; do
                local usage=$(echo "${THREAD_CNT}" | awk -F"/" '{printf "%d\n", $1/$2*100}')
                if [ "${usage}" -ge "${THREAD_LIMIT}" ]; then
                    print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${THREAD_CNT} ${TOMCAT_INST_NAME[$index]} ${THREAD_NAME}]"
                else
                    print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${THREAD_CNT} ${TOMCAT_INST_NAME[$index]} ${THREAD_NAME}]"
                fi
            done < "${RESULT}"
        fi
    done
    rm -rf "${RESULT}" "${RESULT_TMP}"
}

###########################################################################
##  Function Name : Tomcat_DB_Pool
##  Description : Check Tomcat DB Pool Usage
##  information : need probe deployment & lynx pachage
###########################################################################
Tomcat_DB_Pool() {
    local PAGE=datasources.htm
    local RESULT=${PROBE_TMP}.${USER}.${RANDOM}
    local RESULT_TMP=${PROBE_TMP}.${USER}.${RANDOM}

    for index in "${!TOMCAT_INST_NAME[@]}"; do
        local port="${TOMCAT_HTTP_PORT[${index}]}"
        local url
        local is_run

        if [[ "${port}" == *":"* ]]; then
            is_run=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep -c "^${port}$")
            url="http://${port}/probe/${PAGE}"
        else
            is_run=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep -c ":${port}$")
            url="http://127.0.0.1:${port}/probe/${PAGE}"
        fi

        if [ "${is_run}" -eq 1 ]; then
            lynx ${OPT} "${url}" > "${RESULT_TMP}" 2>/dev/null

            if grep -q "There are no data sources configured for this Tomcat instance" "${RESULT_TMP}"; then
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${TOMCAT_INST_NAME[$index]} No.DS.Config]"
                continue
            fi

            local line1=$(awk '/App[ ]*Resource[ ]*Usage[ ]*/ {print NR}' "${RESULT_TMP}")
            local line2=$(awk '/[ ]*\* Applications$|[ ]*\* Applications $/ {print NR}' "${RESULT_TMP}" | tail -1)

            if [ -z "${line1}" ] || [ -z "${line2}" ]; then
                continue
            fi

            sed -n "$((line1 + 1)),$((line2 - 2))p" "${RESULT_TMP}" \
                | grep -v "+ + + + + + + + + + + +" \
                | sed -e "N;s/\n//g" \
                | grep -Ev "\s/probe|\serror" \
                | grep -E "tomcat-jdbc|tomcat-dbcp" > "${RESULT}"

            grep "^ *error " "${RESULT}" > "${RESULT}_error"; > "${RESULT}_ok"

            while read -r line; do
                if ! echo "$line" | grep -q "^/"; then
                    line="/ ${line}"
                fi
                local head=$(echo "${line}" | awk '{print $1, $2, $3, $4, $5, $6}')
                local body_temp=$(echo "${line}" | awk '{for (i=7; i<=(NF-2); i++) print $i}')
                local body=$(echo "${body_temp}" | sed 's/\(.\) /\1/g')
                local tail=$(echo "${line}" | awk '{print $(NF-1), $NF}')
                echo "${head} ${body} ${tail}" | awk '{printf "%s/%s %s %s %s\n", $(NF-4), $(NF-6), $(NF-2), $(NF-7), $1}' >> "${RESULT}_ok"
            done < "${RESULT}"

            while read -r dbpool_cnt dburl dbpool_name context; do
                local usage=$(echo "${dbpool_cnt}" | awk -F"/" '{printf "%d\n", $1/$2*100}')
                if [ "${usage}" -ge "${DBPOOL_LIMIT}" ]; then
                    print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${dbpool_cnt} ${TOMCAT_INST_NAME[$index]} ${context} ${dbpool_name} ${dburl}]"
                else
                    print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${dbpool_cnt} ${TOMCAT_INST_NAME[$index]} ${context} ${dbpool_name} ${dburl}]"
                fi
            done < "${RESULT}_ok"

            while read -r dbpool_status app dbpool_name dummy; do
                print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${dbpool_status} ${TOMCAT_INST_NAME[$index]} ${dbpool_name}]"
            done < "${RESULT}_error"
        fi
    done

    rm -rf "${RESULT}" "${RESULT}_ok" "${RESULT}_error" "${RESULT_TMP}"
}
 
###########################################################################
##  Function Name : Tomcat_Deploy_Status
##  Description : Check Tomcat Application Deploy Status
##  information : need probe deployment & lynx pachage
###########################################################################
Tomcat_Deploy_Status() {
    local PAGE=index.htm

    for index in "${!TOMCAT_INST_NAME[@]}"; do
        local port="${TOMCAT_HTTP_PORT[${index}]}"
        local is_run
        local url

        if [[ "${port}" == *":"* ]]; then
            is_run=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep -c "^${port}$")
            url="http://${port}/probe/${PAGE}"
        else
            is_run=$(grep "LISTEN " "${NETSTAT_INFO}" | awk '{print $4}' | grep -c ":${port}$")
            url="http://127.0.0.1:${port}/probe/${PAGE}"
        fi

        if [ "${is_run}" -eq 1 ]; then
            local result_tmp="${PROBE_TMP}.${USER}.${RANDOM}"
            lynx ${OPT} "${url}" > "${result_tmp}" 2>/dev/null

            local line1=$(awk '/[ ]*Name/ {print NR}' "${result_tmp}")
            local line2=$(awk '/[ ]*\* Applications$|[ ]*\* Applications $/ {print NR}' "${result_tmp}" | tail -1)

            if [ -z "${line1}" ] || [ -z "${line2}" ]; then
                continue
            fi

            local tmp_1="${PROBE_TMP}.${USER}.${RANDOM}"

            case ${PROBE_VERSION} in
                "3")
                    sed -n "$((line1 + 1)),$((line2 - 2))p" "${result_tmp}" \
                        | grep -v "+ + + + + + + + + + + +" \
                        | sed -e "N;s/\n//g" \
                        | awk '{print $2, $3, $(NF-7), $(NF-6), $(NF-3), $(NF-1)}' > "${tmp_1}"
                    ;;
                "2")
                    sed -n "$((line1 + 1)),$((line2 - 2))p" "${result_tmp}" \
                        | grep -v "+ + + + + + + + + + + +" \
                        | sed -e "N;N;N;s/\n//g" \
                        | awk '{print $2, $3, $(NF-7), $(NF-6), $(NF-3), $(NF-1)}' > "${tmp_1}"
                    ;;
            esac

            while read -r context status req_cnt session_cnt session_timeout is_clustered; do
                if [ "${status}" == "running" ]; then
                    print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${status} ${TOMCAT_INST_NAME[$index]} ${context} CNT:${req_cnt} T/O:${session_timeout}-CRST:${is_clustered}]"
                else
                    print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${status} ${TOMCAT_INST_NAME[$index]} ${context} CNT:${req_cnt} T/O:${session_timeout}-CRST:${is_clustered}]"
                fi
            done < "${tmp_1}"

            rm -rf "${tmp_1}" "${result_tmp}"
        fi
    done
}

###########################################################################
##  Function Name : Tomcat_GC_TIME
##  Description : Check whether the GC time has exceeded the GC_LIMIT(web_mon_cron.env)
##  information :
###########################################################################
Tomcat_GC_TIME()
{
    for gcdir in "${GCLOG_DIR[@]}"; do
        if [ -z "$(ls -A "${gcdir}")" ]; then
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[${gcdir}]"
            continue
        fi

        local logfile=$(ls -alrt "${gcdir}"/gc* 2>/dev/null | tail -1 | awk '{print $NF}')
        if [ -z "${logfile}" ]; then
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[${gcdir}]"
            continue
        fi

        local filename=$(basename "${logfile}")
        local gc_line_cnt="${gcdir}/linecnt.${USER}.${filename}"
        touch "${gc_line_cnt}"

        if [ ! -s "${logfile}" ]; then
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[No.GC.Occurred" "${logfile}]"
            continue
        fi

        local iflag=$(wc -l < "${gc_line_cnt}")

        if [ "${iflag}" -eq 0 ]; then
            wc -l < "${logfile}" > "${gc_line_cnt}"
            local last_gc_time=$(tail -160 "${logfile}" | grep "Times:" | awk '{print $(NF-1)}' | cut -d'=' -f2 | sort -n | tail -1)
        else
            local iprev_line=$(tail -1 "${gc_line_cnt}")
            local iline=$(wc -l < "${logfile}")
            local igap=$((iline - iprev_line))
            echo "${iline}" > "${gc_line_cnt}"
            local last_gc_time=$(tail -${igap} "${logfile}" | grep "Times:" | awk '{print $(NF-1)}' | cut -d'=' -f2 | sort -n | tail -1)
        fi

        if [ -n "${last_gc_time}" ]; then
            local flag=$(awk -v time="${last_gc_time}" -v limit="${GC_LIMIT}" 'BEGIN { print (time > limit) ? 1 : 0 }')
            if [ "${flag}" -eq 0 ]; then
                print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${last_gc_time}_sec" "${logfile}]"
            else
                print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${last_gc_time}_sec" "${logfile}]"
            fi
        else
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[No.GC.Since.Last.Chk" "${logfile}]"
        fi
    done
}

###########################################################################
##  Function Name : Tomcat_HeapDump
##  Description : Check the heapdump file is created in the dump directory
##  information :
###########################################################################
Tomcat_HeapDump()
{
    for dump_dir in "${HEAPDUMP_DIR[@]}"; do
        if [ ! -d "${dump_dir}" ] || [ -z "$ls -A "${dump_dir}")" ]; then
            local dump_cnt=0
        else
            local dump_cnt=$(find "${dump_dir}" -type f -name "*.hprof" -mmin -5 | wc -l)
        fi

        if [ "${dump_cnt}" -eq 0 ]; then
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${dump_dir}]"
        else
            print_msg_nok "${DATE}" "${USER}" "${FUNCNAME[0]}" "NOT.OK" "[${dump_cnt}" "${dump_dir}]"
            if [ -n "${APPL_SMS}" ]; then
                echo "[${DATE} - ${USER}] ${FUNCNAME[0]} : NOT.OK [${dump_cnt} ${dump_dir}]" >> "${APPL_SMS}"
            fi
        fi
    done
}

###########################################################################
##  Function Name : Tomcat_Engine_Log
##  Description : Check Log File Exist, and call log_file_scan()
##  information : This function only check whether file exist
###########################################################################
Tomcat_Engine_Log()
{
    for index in "${!TOMCAT_INST_NAME[@]}"; do
        local log_dir="${TOMCAT_LOG_DIR[${index}]}"
        local inst_name="${TOMCAT_INST_NAME[${index}]}"
        local catalina_log="${log_dir}/catalina.out"
        local localhost_log="${log_dir}/localhost.${DATE2}.log"
        local line_cnt_catalina="/tmp/linecnt.${USER}.${inst_name}.catalina"
        local line_cnt_localhost="/tmp/linecnt.${USER}.${inst_name}.localhost"

        [ "${log_dir}" = "-" ] && continue

        touch "${line_cnt_catalina}" "${line_cnt_localhost}"

        if [ -f "${catalina_log}" ]; then
            log_file_scan "${inst_name}" "${catalina_log}" "${line_cnt_catalina}" "${FUNCNAME[0]}"
        else
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[${catalina_log}]"
        fi

        if [ -f "${localhost_log}" ]; then
            log_file_scan "${inst_name}" "${localhost_log}" "${line_cnt_localhost}" "${FUNCNAME[0]}"
        else
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[${localhost_log}]"
        fi
    done
}

###########################################################################
##  Function Name : Tomcat_Access_Log
##  Description : Check Log File Exist, and call log_file_scan()
##  information : This function only check whether file exist
###########################################################################
Tomcat_Access_Log()
{
    for index in "${!TOMCAT_INST_NAME[@]}"; do
        local log_dir="${TOMCAT_LOG_DIR[${index}]}"
        local inst_name="${TOMCAT_INST_NAME[${index}]}"
        local access_log="${log_dir}/localhost_access.${DATE2}.log"
        local line_cnt="/tmp/linecnt.${USER}.${inst_name}.localhost_access"

        [ "${log_dir}" = "-" ] && continue

        touch "${line_cnt}"

        if [ -f "${access_log}" ]; then
            log_file_scan "${inst_name}" "${access_log}" "${line_cnt}" "${FUNCNAME[0]}"
        else
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[${access_log}]"
        fi
    done
}

###########################################################################
##  Function Name : Tomcat_Extra_Log
##  Description : Check Log File Exist, and call log_file_scan()
##  information : This function only check whether file exist
###########################################################################
Tomcat_Extra_Log()
{
    for index in "${!TOMCAT_EXTRA_LOG[@]}"; do
        local log_file="${TOMCAT_EXTRA_LOG[${index}]}"
        local line_cnt="/tmp/linecnt.${USER}.tomcat${index}.extralog"

        touch "${line_cnt}"

        if [ -f "${log_file}" ]; then
            log_file_scan "tomcat${index}" "${log_file}" "${line_cnt}" "${FUNCNAME[0]}"
        else
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "NoFile" "[${log_file}]"
        fi
    done
}

###########################################################################
##  Function Name : Tomcat_Boot_Time
##  Description : Check Time When Apache Process started.
##  information : 
###########################################################################
Tomcat_Boot_Time()
{
    for SERVER_NAME in "${TOMCAT_INST_NAME[@]}"; do
        local tomcat_boot_time
        tomcat_boot_time=$(grep "java" "$PS_INFO" | egrep "D${SERVER_NAME} |SERVER_NAME=${SERVER_NAME} " | egrep -vw "vi|vim|tail|cat|grep|more" | awk '{print $4,$5,$6,$7,$8}')
        
        if [ -n "${tomcat_boot_time}" ]; then
            local tomcat_boot_time_prt
            tomcat_boot_time_prt=$(date --date "${tomcat_boot_time}" +'%Y-%m-%d(%a) %H:%M:%S')
            print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "OK" "[${tomcat_boot_time_prt}" "${SERVER_NAME}]"
        #else
        #    print_msg "${DATE}" "${USER}" "${FUNCNAME[0]}" "CHECK" "[${SERVER_NAME}]"
        fi
    done
}

###########################################################################
##  Function Name : main
##  Description : This is a main function, call sub functions.
##  information : 
###########################################################################
main()
{
    common

    chkshl_ppid_chk
    if [ "${ppidchk}" -eq 1 ]; then
        SMS_LOG=/dev/null
        CLOUD_LOG=/dev/null
    fi

    mon_cron_cnt

    if [ -d "${APACHE_HOME}" ] && [ -n "${APACHE_HOME}" ]; then
        web_info_chk
        Apache_Daemon
        Apache_HTTP_PORT
        Apache_HTTPS_PORT
        Apache_SSL_VALID
        if [ "${SSO_CHECK}" = "Y" ]; then
            Apache_SSO_Filter
        fi
        Apache_Thread_Pool
        Apache_Engine_Log
        Apache_Access_Log
        Apache_Mod_jk_Log
        Apache_Extra_Log
        Apache_Boot_Time
    fi

    if [ -d "${TOMCAT_HOME}" ] && [ -n "${TOMCAT_HOME}" ]; then
        was_info_chk
        Tomcat_Container
        Tomcat_PORT
        Tomcat_SSL_VALID
        if [ "${PROBE_CHECK}" = "Y" ]; then
            Tomcat_Thread_Pool
            Tomcat_DB_Pool
            Tomcat_Deploy_Status
        fi
        Tomcat_GC_TIME
        Tomcat_HeapDump
        Tomcat_Engine_Log
        Tomcat_Access_Log
        Tomcat_Extra_Log
        Tomcat_Boot_Time

    fi

    FileSystem

    if [ "$(cat ${HEALTH_RESULT})" -eq 0 ]; then
        remove_tmp_files
        exit 0
    else
        remove_tmp_files
        exit 1
    fi
}

main
